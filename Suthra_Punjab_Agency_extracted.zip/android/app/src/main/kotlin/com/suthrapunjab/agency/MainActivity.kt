package com.suthrapunjab.agency

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
