# Suthra Punjab Agency - next steps

The Android platform scaffold and Codemagic build workflow have been added.

Before a production APK can work with login, attendance, complaints, Firestore, storage and notifications, configure Firebase for the Android application and replace `lib/firebase_options.dart` using FlutterFire.

Android package name: `com.suthrapunjab.agency`

Build command: `flutter build apk --release`

Expected output: `build/app/outputs/flutter-apk/app-release.apk`

The official Flutter release documentation confirms that `flutter build apk` creates a release APK; Flutter also recommends app bundles for Google Play distribution. See https://docs.flutter.dev/deployment/android
