// Generated from the Firebase Android configuration.
// Do not commit private server credentials to source control.
import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    return const FirebaseOptions(
      apiKey: 'AIzaSyC-bLwKCSnExK4qtKI03SeJI8yRujvR358',
      appId: '1:398112150022:android:dbf00f2ab27bdadf4ce987',
      messagingSenderId: '398112150022',
      projectId: 'suthra-punjab-agency',
      storageBucket: 'suthra-punjab-agency.firebasestorage.app',
    );
  }
}
