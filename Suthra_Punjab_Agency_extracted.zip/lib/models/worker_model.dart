class WorkerModel {
  final String workerId, name, cnic, phone, area, designation, photoUrl, status;
  const WorkerModel({required this.workerId, required this.name, required this.cnic, required this.phone, required this.area, required this.designation, this.photoUrl='', this.status='Active'});
  factory WorkerModel.fromMap(Map<String,dynamic> m)=>WorkerModel(workerId:m['workerId']??'',name:m['name']??'',cnic:m['cnic']??'',phone:m['phone']??'',area:m['area']??'',designation:m['designation']??'',photoUrl:m['photoUrl']??'',status:m['status']??'Active');
  Map<String,dynamic> toMap()=>{'workerId':workerId,'name':name,'cnic':cnic,'phone':phone,'area':area,'designation':designation,'photoUrl':photoUrl,'status':status};
}
