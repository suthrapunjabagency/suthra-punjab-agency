import 'package:cloud_firestore/cloud_firestore.dart';
class AttendanceService {
  final db=FirebaseFirestore.instance;
  Future<void> markAttendance({required String workerId,required String status,required double latitude,required double longitude,required bool qrVerified}) async {
    final n=DateTime.now(); final id='${workerId}_${n.year}${n.month.toString().padLeft(2,'0')}${n.day.toString().padLeft(2,'0')}';
    await db.collection('attendance').doc(id).set({'attendanceId':id,'workerId':workerId,'date':Timestamp.fromDate(DateTime(n.year,n.month,n.day)),'checkIn':Timestamp.fromDate(n),'latitude':latitude,'longitude':longitude,'qrVerified':qrVerified,'status':status},SetOptions(merge:true));
  }
}
