import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/worker_model.dart';
class WorkerService {
  final db=FirebaseFirestore.instance;
  Stream<QuerySnapshot<Map<String,dynamic>>> workers()=>db.collection('workers').orderBy('createdAt',descending:true).snapshots();
  Future<void> addWorker(WorkerModel w)=>db.collection('workers').doc(w.workerId).set({...w.toMap(),'createdAt':FieldValue.serverTimestamp()});
  Future<void> deleteWorker(String id)=>db.collection('workers').doc(id).delete();
}
