import 'package:cloud_firestore/cloud_firestore.dart';
class ComplaintService {
  final db=FirebaseFirestore.instance;
  Stream<QuerySnapshot<Map<String,dynamic>>> complaints()=>db.collection('complaints').orderBy('createdAt',descending:true).snapshots();
  Future<void> addComplaint({required String citizenName,required String phone,required String area,required String description}) async { final r=db.collection('complaints').doc(); await r.set({'complaintId':r.id,'citizenName':citizenName,'phone':phone,'area':area,'description':description,'status':'Pending','assignedWorker':'','createdAt':FieldValue.serverTimestamp()}); }
  Future<void> updateStatus(String id,String status)=>db.collection('complaints').doc(id).update({'status':status});
  Future<void> assignWorker(String id,String worker)=>db.collection('complaints').doc(id).update({'assignedWorker':worker,'status':'Assigned'});
}
