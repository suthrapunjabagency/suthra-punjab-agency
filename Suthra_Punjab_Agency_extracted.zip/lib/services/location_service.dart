import 'package:geolocator/geolocator.dart';
class LocationService {
  Future<Position> currentPosition() async {
    if(!await Geolocator.isLocationServiceEnabled()) throw Exception('Location service is disabled');
    var p=await Geolocator.checkPermission();
    if(p==LocationPermission.denied) p=await Geolocator.requestPermission();
    if(p==LocationPermission.denied||p==LocationPermission.deniedForever) throw Exception('Location permission denied');
    return Geolocator.getCurrentPosition();
  }
}
