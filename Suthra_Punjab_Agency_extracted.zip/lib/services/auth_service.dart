import 'package:firebase_auth/firebase_auth.dart';
class AuthService {
  final _auth=FirebaseAuth.instance;
  User? get currentUser=>_auth.currentUser;
  Future<void> login(String email,String password)=>_auth.signInWithEmailAndPassword(email:email,password:password).then((_){});
  Future<void> logout()=>_auth.signOut();
  Future<void> changePassword(String password) async { final u=_auth.currentUser; if(u==null) throw Exception('No signed-in user'); await u.updatePassword(password); }
}
