import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/theme_provider.dart';
import '../../providers/language_provider.dart';
import '../../services/auth_service.dart';
import '../login/login_screen.dart';
class SettingsScreen extends StatelessWidget{const SettingsScreen({super.key});@override Widget build(BuildContext c){final t=c.watch<ThemeProvider>();final l=c.watch<LanguageProvider>();return Scaffold(appBar:AppBar(title:const Text('Settings')),body:ListView(children:[SwitchListTile(title:const Text('Dark Mode'),value:t.darkMode,onChanged:t.toggleTheme),ListTile(title:const Text('Language'),trailing:DropdownButton<String>(value:l.locale.languageCode,items:const[DropdownMenuItem(value:'en',child:Text('English')),DropdownMenuItem(value:'ur',child:Text('اردو'))],onChanged:(v){if(v!=null)l.changeLanguage(v);})),ListTile(leading:const Icon(Icons.logout),title:const Text('Logout'),onTap:()async{await AuthService().logout();if(c.mounted)Navigator.pushAndRemoveUntil(c,MaterialPageRoute(builder:(_)=>const LoginScreen()),(_)=>false);})]));}}
