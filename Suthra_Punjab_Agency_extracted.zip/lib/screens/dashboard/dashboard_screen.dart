import 'package:flutter/material.dart';
import '../workers/workers_screen.dart';
import '../attendance/attendance_screen.dart';
import '../complaints/complaint_screen.dart';
import '../reports/reports_screen.dart';
import '../settings/settings_screen.dart';
class DashboardScreen extends StatelessWidget{const DashboardScreen({super.key});
Widget tile(BuildContext c,String t,String s,IconData i,Widget w)=>Card(child:ListTile(leading:Icon(i,size:34),title:Text(t),subtitle:Text(s),trailing:const Icon(Icons.arrow_forward_ios),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>w))));
@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Suthra Punjab Agency')),body:ListView(padding:const EdgeInsets.all(16),children:[const Text('Admin Dashboard',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),const SizedBox(height:12),tile(c,'Workers','Registration and profiles',Icons.people,const WorkersScreen()),tile(c,'Attendance','GPS and QR attendance',Icons.check_circle,const AttendanceScreen()),tile(c,'Complaints','Citizen complaints',Icons.report_problem,const ComplaintScreen()),tile(c,'Reports','PDF and Excel',Icons.assessment,const ReportsScreen()),tile(c,'Settings','Language, theme and logout',Icons.settings,const SettingsScreen())]));}
}
