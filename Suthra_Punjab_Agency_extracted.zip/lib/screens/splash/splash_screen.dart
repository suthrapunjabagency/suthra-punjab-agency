import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../dashboard/dashboard_screen.dart';
import '../login/login_screen.dart';
class SplashScreen extends StatefulWidget { const SplashScreen({super.key}); @override State<SplashScreen> createState()=>_SplashScreenState(); }
class _SplashScreenState extends State<SplashScreen>{
  @override void initState(){super.initState(); Future.delayed(const Duration(seconds:2),(){if(!mounted)return; Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>FirebaseAuth.instance.currentUser==null?const LoginScreen():const DashboardScreen()));});}
  @override Widget build(BuildContext context)=>const Scaffold(body:Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(Icons.cleaning_services,size:90),SizedBox(height:18),Text('Suthra Punjab Agency',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold))])));
}
