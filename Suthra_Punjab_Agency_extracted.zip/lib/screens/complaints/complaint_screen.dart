import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../services/complaint_service.dart';
import 'add_complaint_screen.dart';
class ComplaintScreen extends StatelessWidget{const ComplaintScreen({super.key});@override Widget build(BuildContext c){final s=ComplaintService();return Scaffold(appBar:AppBar(title:const Text('Complaints')),floatingActionButton:FloatingActionButton(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const AddComplaintScreen())),child:const Icon(Icons.add)),body:StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:s.complaints(),builder:(c,x){if(!x.hasData)return const Center(child:CircularProgressIndicator());return ListView(children:[for(final d in x.data!.docs)Card(child:ListTile(title:Text(d.data()['description']??''),subtitle:Text('${d.data()['citizenName']??''} • ${d.data()['area']??''}'),trailing:Chip(label:Text(d.data()['status']??'Pending'))))]);}));}}
