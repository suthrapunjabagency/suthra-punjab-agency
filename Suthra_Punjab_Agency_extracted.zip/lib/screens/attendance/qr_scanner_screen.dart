import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
class QRScannerScreen extends StatelessWidget{const QRScannerScreen({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Scan Worker QR')),body:MobileScanner(onDetect:(capture){for(final b in capture.barcodes){final v=b.rawValue;if(v!=null&&v.isNotEmpty){Navigator.pop(c,v);return;}}}));}
