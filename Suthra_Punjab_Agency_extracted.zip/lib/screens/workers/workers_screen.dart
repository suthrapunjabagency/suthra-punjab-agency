import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../models/worker_model.dart';
import '../../services/worker_service.dart';
import 'add_worker_screen.dart';
import 'worker_profile_screen.dart';
class WorkersScreen extends StatelessWidget{const WorkersScreen({super.key});@override Widget build(BuildContext c){final s=WorkerService();return Scaffold(appBar:AppBar(title:const Text('Workers')),floatingActionButton:FloatingActionButton(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const AddWorkerScreen())),child:const Icon(Icons.add)),body:StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:s.workers(),builder:(c,x){if(x.hasError)return const Center(child:Text('Error'));if(!x.hasData)return const Center(child:CircularProgressIndicator());final d=x.data!.docs;if(d.isEmpty)return const Center(child:Text('No workers'));return ListView.builder(itemCount:d.length,itemBuilder:(_,i){final w=WorkerModel.fromMap(d[i].data());return Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text(w.name),subtitle:Text('${w.designation} • ${w.area}\n${w.phone}'),isThreeLine:true,onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>WorkerProfileScreen(worker:w))),trailing:IconButton(icon:const Icon(Icons.delete),onPressed:()=>s.deleteWorker(w.workerId)));});}));}}
