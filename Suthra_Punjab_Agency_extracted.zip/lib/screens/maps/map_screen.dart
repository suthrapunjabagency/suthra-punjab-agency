import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
class MapScreen extends StatelessWidget{final double latitude,longitude;const MapScreen({super.key,required this.latitude,required this.longitude});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Location')),body:GoogleMap(initialCameraPosition:CameraPosition(target:LatLng(latitude,longitude),zoom:16),markers:{Marker(markerId:const MarkerId('location'),position:LatLng(latitude,longitude))}));}
