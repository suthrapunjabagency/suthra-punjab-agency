import 'package:flutter/material.dart';
class LanguageProvider extends ChangeNotifier {
  Locale locale = const Locale('en');
  void changeLanguage(String code) { locale = Locale(code); notifyListeners(); }
}
