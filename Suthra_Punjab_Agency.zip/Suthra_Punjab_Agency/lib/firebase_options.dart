// PLACEHOLDER: run `flutterfire configure` to generate the real file.
import 'package:firebase_core/firebase_core.dart';
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform => throw UnsupportedError(
    'Firebase is not configured. Run flutterfire configure.',
  );
}
